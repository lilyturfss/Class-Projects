# Music Player 

'''
REFERENCES:
1. https://www.w3schools.com/python/ref_func_isinstance.asp
2. https://flet.dev/docs/controls/filepicker/
3. https://www.w3schools.com/python/ref_keyword_nonlocal.asp 
'''

import flet as ft

def main(page: ft.Page):
    global audio
    song_list = {"Linger - The Cranberries": "musicPlayer/Linger - The Cranberries.mp3",
                 "Blue Hair - TV Girl": "musicPlayer/Blue Hair - TV Girl.mp3",
                 "I Just Threw Out The Love Of My Dreams - Weezer": "musicPlayer/I Just Threw Out The Love Of My Dreams - Weezer.mp3",
                 "For A Pessimist, I'm Pretty Optimistic - Paramore":"musicPlayer/For A Pessimist, I'm Pretty Optimistic - Paramore.mp3",
                 "???":"musicPlayer/random.mp3"}
    song_titles = list(song_list.keys())
    mp3names = list(song_list.values())
    global current_song_index
    current_song_index = -1

    # PAUSE AND PLAY FUNCTIONS-------------------------------------------
    def play_pause(e):
        try:
            if buttons_row.controls[1].icon == ft.icons.PAUSE_CIRCLE_FILLED_ROUNDED:
                audio.pause()
                buttons_row.controls[1].icon = ft.icons.PLAY_CIRCLE_FILLED_ROUNDED
                print(audio.src)
            else:
                print(audio.src)
                audio.play()
                buttons_row.controls[1].icon = ft.icons.PAUSE_CIRCLE_FILLED_ROUNDED
        except Exception as e:
            print("No song playing")
            print(e)
        page.update()

    # SKIP SONGS---------------------------------------------------------
    def skip_song(forward=True):
        global current_song_index
        if forward:
            current_song_index = (current_song_index + 1) % len(song_titles)
        else:
            current_song_index = (current_song_index - 1) % len(song_titles)
        
        if current_song_index > 4:
            current_song_index = 0
        
        audio.src = mp3names[current_song_index]
        print(current_song_index)

        update_page()
        page.update()

    def previous_click(e):
        skip_song(forward=False)

    def next_click(e):
        skip_song(forward=True)

    audio = ft.Audio(
        src=mp3names[current_song_index],
        autoplay=True,
        volume=100,
    )

    def update_page():
        progress_column.controls[0] = ft.Text(f"{song_titles[current_song_index]}")
        page.update()

    # PAGE ATTRIBUTES----------------------------------------------------
    page.title = "Music Player"
    page.horizontal_alignment = "CENTER"
    page.vertical_alignment = "CENTER"
    page.bgcolor = "#36454f"
    page.window_width = 350
    page.window_height = 400
    page.window_resizable = False 

    # TITLE--------------------------------------------------------------
    title = ft.Text(value="Music Player", color="white", size=50, height=60, weight=ft.FontWeight.BOLD)
    title_row = ft.Container(content= title, alignment=ft.alignment.top_center)
    song_name = ft.Text("No song selected", style="headlineSmall")

    # PROGRESS BAR-------------------------------------------------------
    progress = ft.ProgressBar(width = 270)
    progress_column = ft.Column(controls=[song_name,progress], alignment=ft.MainAxisAlignment.CENTER)

    buttons_row = ft.Row(controls=[
        ft.ElevatedButton(text = "<", on_click=previous_click),
        ft.IconButton(icon = ft.icons.PLAY_CIRCLE_FILLED_ROUNDED,
                      icon_color = "#FFFFFF", on_click=play_pause,
                      icon_size= 60),
        ft.ElevatedButton(text=">", on_click=next_click)
    ], alignment= ft.MainAxisAlignment.CENTER)

    page.overlay.append(audio)

    page.add(title_row, progress_column, buttons_row)
    page.update()

ft.app(target=main)